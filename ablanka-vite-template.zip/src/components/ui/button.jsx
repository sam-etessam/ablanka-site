export function Button({ children, className = "", variant = "solid", ...props }) {
  const base = "rounded-xl px-4 py-2 font-medium shadow transition";
  const styles = variant === "outline"
    ? "border border-blue-600 text-blue-700 bg-white hover:bg-blue-50"
    : "bg-blue-700 text-white hover:bg-blue-800";
  return (
    <button className={`${base} ${styles} ${className}`} {...props}>
      {children}
    </button>
  );
}